from datetime import datetime

# Force debug log to file
with open("startup_debug.log", "a") as f:
    f.write(f"✅ run.py started at {datetime.now()}\n")

print("✅ WebJob started!", flush=True)

# Ensure requests is installed
import os
import sys
import subprocess
import time
from datetime import datetime
import csv

print("✅ WebJob started at", datetime.now(), flush=True)

# Ensure requests is installed
try:
    import requests
except ImportError:
    print("📦 Installing requests...", flush=True)
    subprocess.check_call([sys.executable, "-m", "pip", "install", "requests"])
    import requests

print("✅ Dependencies are ready.", flush=True)

# --------------- Configuration -----------------

THINGSBOARD_URL = "https://thingsboard.cloud"
USERNAME = "dennis.wong002@umb.edu"  # <-- your ThingsBoard login
PASSWORD = 123456  # <-- your ThingsBoard password
DEVICE_ID = "8b534c60-1667-11f0-8f83-43727cd6bc90"  # <-- your deviceId (UUID)

FETCH_INTERVAL = 10  # Fetch every 300 seconds (5 minutes)
TOKEN_REFRESH_INTERVAL = 3000  # Refresh login every 50 minutes
DATA_KEYS = "TempF,Humidity"
CSV_FILENAME = os.path.join(os.getcwd(), datetime.now().strftime("%d-%m-%Y") + ".csv")

# ------------------------------------------------

session = requests.Session()
jwt_token = None
token_last_refresh_time = None


def login(max_retries=3, delay=10):
    global jwt_token, token_last_refresh_time
    login_url = f"{THINGSBOARD_URL}/api/auth/login"
    credentials = {"username": USERNAME, "password": PASSWORD}

    for attempt in range(max_retries):
        try:
            response = session.post(login_url, json=credentials)
            if response.status_code == 200:
                jwt_token = response.json().get("token")
                token_last_refresh_time = time.time()
                print(f"[{datetime.now()}] ✅ Logged in successfully.", flush=True)
                return
            else:
                print(f"[{datetime.now()}] ❌ Login failed (attempt {attempt + 1}): {response.text}", flush=True)
        except Exception as e:
            print(f"[{datetime.now()}] ❌ Login exception (attempt {attempt + 1}): {e}", flush=True)
        time.sleep(delay)

    raise Exception("Login failed after multiple attempts.")


def fetch_telemetry(max_retries=3, delay=10):
    telemetry_url = f"{THINGSBOARD_URL}/api/plugins/telemetry/DEVICE/{DEVICE_ID}/values/timeseries?keys={DATA_KEYS}"
    headers = {"Authorization": f"Bearer {jwt_token}"}

    for attempt in range(max_retries):
        try:
            response = session.get(telemetry_url, headers=headers)
            if response.status_code == 200:
                return response.json()
            else:
                print(f"[{datetime.now()}] ❌ Telemetry fetch failed (attempt {attempt + 1}): {response.status_code}")
                print(response.text)
        except Exception as e:
            print(f"[{datetime.now()}] ❌ Telemetry fetch exception (attempt {attempt + 1}): {e}")
        time.sleep(delay)

    print(f"[{datetime.now()}] ⚠️ Giving up telemetry fetch after {max_retries} attempts.")
    return None


def save_to_csv(data):
    # Prepare the row
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    temp = data.get("TempF", [{}])[0].get("value", "N/A")
    humidity = data.get("Humidity", [{}])[0].get("value", "N/A")

    row = [timestamp, temp, humidity]

    # Create CSV file if doesn't exist
    try:
        with open(CSV_FILENAME, "x", newline="") as file:
            writer = csv.writer(file)
            writer.writerow(["Timestamp", "Temperature (°F)", "Humidity (%)"])
    except FileExistsError:
        pass  # Already exists

    # Append new data
    with open(CSV_FILENAME, "a", newline="") as file:
        writer = csv.writer(file)
        writer.writerow(row)

    print(f"[{datetime.now()}] 📥 Saved: Temp={temp}°C, Humidity={humidity}%", flush=True)


# ----------------- Main Loop -------------------

def _main():
    try:
        login()

        while True:
            # Refresh token if needed
            if time.time() - token_last_refresh_time > TOKEN_REFRESH_INTERVAL:
                print(f"[{datetime.now()}] 🔄 Refreshing JWT token...", flush=True)
                login()

            # Fetch telemetry
            data = fetch_telemetry()
            if data:
                save_to_csv(data)

            # Wait before next fetch
            time.sleep(FETCH_INTERVAL)

    except KeyboardInterrupt:
        print("\n🛑 Program stopped by user.")
    except Exception as e:
        print(f"\n❌ Error: {str(e)}")


if __name__ == '__main__':
    _main()
